﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class detector : MonoBehaviour
{
    private GameObject gate, esteira3;
    public float readingTime = 0.1f;
    public float stopConveyourDelay = 1.0f;
    private int canCounter;
    // Start is called before the first frame update
    void Start()
    {
        gate = GameObject.Find("Gate");
        esteira3 = GameObject.Find("Esteira3");
        canCounter = 0;
    }

    // Update is called once per frame
    void OnTriggerEnter(Collider other)
    {
        if (other.tag == "boa")
        {
            //Debug.Log("lata boa detectada");
            Invoke("ReadGoodCan", Random.Range(readingTime * 0.8f, readingTime*1.2f));
            canCounter += 1;
            if (canCounter >= 9) {
                Invoke("StartConv2", stopConveyourDelay);
                canCounter = 0;
            }
        }
        else {
            //Debug.Log("lata ruim detectada");
            Invoke("ReadBadCan", Random.Range(readingTime * 0.8f, readingTime * 1.2f));
        }
    }

    private void ReadBadCan(){
        gate.GetComponent<gateScript>().goGate();
    }
    private void ReadGoodCan(){
        gate.GetComponent<gateScript>().goBackGate();
    }
    private void StartConv2(){
        esteira3.GetComponent<conveyour2>().start();
    }
    
}
