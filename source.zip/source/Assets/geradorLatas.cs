﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class geradorLatas : MonoBehaviour
{
    // Start is called before the first frame update
    public float chance = 0.2f;
    public float period = 1f;
    public GameObject lataBoa;
    public GameObject lataRuim;
    private GameObject lata;
    void Start()
    {
        Invoke("CreateCan", period);
    }

    // Update is called once per frame
    private void CreateCan()
    {
        float rand = Random.Range(0.0f, 1.0f);
        if ( rand> chance)
        {
            lata = lataBoa;
        }
        else {
            lata = lataRuim;
        }
        Vector3 pos = transform.position;
        Instantiate(lata, pos, Quaternion.identity);
        Invoke("CreateCan", period);
        //Debug.Log(rand);
    }
}
