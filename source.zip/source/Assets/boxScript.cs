﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class boxScript : MonoBehaviour
{
    private int latas;
    public GameObject lata;
    public Vector3 startPos;
    public Vector3 step1;
    public Vector3 step2;
    private GameObject esteira3;

    // Start is called before the first frame update
    void Start()
    {
         latas = 0;
         esteira3 = GameObject.Find("Esteira3");
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.tag == "boa") {
            if (latas < 9)
            {
                Destroy(other.gameObject);
                addLata();
            }
        }
        else if (other.tag == "eoc")
        {
            esteira3.GetComponent<conveyour2>().stop();
            Debug.Log("ASDHAISUDH");
        }
    }

    private void addLata(){
        Instantiate(lata, startPos + transform.position + Mathf.Floor(latas/3)*step1 + latas%3 * step2, Quaternion.identity);
        latas++;
    }
}
