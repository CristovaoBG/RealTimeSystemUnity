﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gateScript : MonoBehaviour
{

    public GameObject axis;
    public float speed = 20f;
    private bool go, goBack;
    private bool eoc, soc;

    private System.DateTime openingTime, closingTime;

    // Start is called before the first frame update
    void Start()
    {
        go = true;
        goBack = false;

        soc = true;
        eoc = false;

        openingTime = System.DateTime.UtcNow;
        closingTime = System.DateTime.UtcNow;

        }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (go) {
            transform.RotateAround(axis.transform.position, Vector3.up, speed * Time.deltaTime);
        }
        else if (goBack) {
            transform.RotateAround(axis.transform.position, Vector3.up, -speed * Time.deltaTime);
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.tag == "eoc")
        {
            go = false;
            eoc = true;
            soc = false;
            //Debug.Log("opening_time " + (System.DateTime.UtcNow - openingTime));
        }
        else if (other.tag == "soc")
        {
            goBack = false;
            eoc = false;
            soc = true;
            //Debug.Log("closing_time " + (System.DateTime.UtcNow - closingTime));
        }
    }


    
    public void goGate()
    {
        if (!eoc)
        {
            openingTime = System.DateTime.UtcNow;
            go = true;
            goBack = false;
        }
    }

    public void goBackGate()
    {
        if (!soc)
        {
            closingTime = System.DateTime.UtcNow;
            go = false;
            goBack = true;
        }
    }



}
