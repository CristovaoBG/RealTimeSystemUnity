﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class conveyour2 : MonoBehaviour
{
    public GameObject box;
    public bool move = false;
    public float speed;
    private Rigidbody rb;
    private Vector3 pos;
    private System.DateTime conv2Time;
    // Start is called before the first frame update

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        Vector3 pos = rb.position;
        conv2Time = System.DateTime.UtcNow;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (move)
        {
            Vector3 pos = rb.position;
            rb.position -= transform.forward * speed * Time.fixedDeltaTime;
            rb.MovePosition(pos);

        }
    }

    public void stop()
    {
        move = false;
        Debug.Log("opening_time " + (System.DateTime.UtcNow - conv2Time));
    }

    public void start()
    {
        conv2Time = System.DateTime.UtcNow;
        GameObject spammer = GameObject.Find("BoxSpammer");
        Instantiate(box, spammer.transform.position,  Quaternion.Euler(0, -90,0));
        move = true;
    }
}
