﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moveCylinder : MonoBehaviour
{
    public Rigidbody rb;
    // Start is called before the first frame update
    void Start()
    {
        rb.angularVelocity = new Vector3(0, 0, 1);
    }

    // Update is called once per frame
    void Update()
    {
        rb.angularVelocity = new Vector3(0, 0, 1);
    }
}
