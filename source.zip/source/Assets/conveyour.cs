﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class conveyour : MonoBehaviour
{
    public float speed;
    private Rigidbody rb;
    private Vector3 pos;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        Vector3 pos = rb.position;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        Vector3 pos = rb.position;
        rb.position -= transform.forward * speed * Time.fixedDeltaTime;
        rb.MovePosition(pos);   
    }
}
